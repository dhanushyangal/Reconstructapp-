import UIKit
import Flutter
import GoogleSignIn
import WidgetKit
import Firebase

@UIApplicationMain
class AppDelegate: FlutterAppDelegate {
    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        
        // Configure Firebase first
        FirebaseApp.configure()
        
        // Configure Google Sign-In
        configureGoogleSignIn()
        
        // Restore Google Sign-In state if needed (with error handling)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            GIDSignIn.sharedInstance.restorePreviousSignIn { user, error in
                if let error = error {
                    print("Google Sign-In restoration error: \(error)")
                } else if let user = user {
                    print("Google Sign-In restored for user: \(user.profile?.email ?? "unknown")")
                }
            }
        }
        
        // Set up method channel for widget communication
        let controller = window?.rootViewController as! FlutterViewController
        let widgetChannel = FlutterMethodChannel(name: "ios_widget_service", binaryMessenger: controller.binaryMessenger)
        
        widgetChannel.setMethodCallHandler { [weak self] (call, result) in
            switch call.method {
            case "updateNotesWidget":
                if let args = call.arguments as? [String: Any],
                   let title = args["title"] as? String,
                   let content = args["content"] as? String {
                    
                    let notesData = SharedDataModel.NotesData(
                        title: title,
                        content: content,
                        lastUpdated: Date()
                    )
                    SharedDataModel.saveNotesData(notesData)
                    result(true)
                } else {
                    result(FlutterError(code: "INVALID_ARGUMENTS", message: "Invalid arguments for Notes widget", details: nil))
                }
                
            case "refreshAllWidgets":
                WidgetCenter.shared.reloadAllTimelines()
                result(true)
                
            default:
                result(FlutterMethodNotImplemented)
            }
        }
        
        GeneratedPluginRegistrant.register(with: self)
        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
    
    private func configureGoogleSignIn() {
        // Try to load GoogleService-Info.plist
        if let path = Bundle.main.path(forResource: "GoogleService-Info", ofType: "plist"),
           let plist = NSDictionary(contentsOfFile: path),
           let clientId = plist["CLIENT_ID"] as? String {
            
            // Configure Google Sign-In with client ID from plist
            GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: clientId)
            print("Google Sign-In configured with client ID: \(clientId)")
            
        } else {
            // Fallback client ID if GoogleService-Info.plist is not found
            let clientId = "633982729642-d6lvv51c28ahcr1g8820a83vka5pb5k9.apps.googleusercontent.com"
            GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: clientId)
            print("Google Sign-In configured with fallback client ID: \(clientId)")
        }
    }
    
    override func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        print("AppDelegate: Received URL: \(url)")
        
        // Handle Google Sign-In with error handling
        if GIDSignIn.sharedInstance.handle(url) {
            print("AppDelegate: Handled Google Sign-In URL: \(url)")
            return true
        }
        
        // Handle deep links (e.g., mentalfitness://notes)
        if url.scheme == "mentalfitness" {
            print("AppDelegate: Received deep link: \(url)")
            return true
        }
        
        // Handle other URLs
        print("AppDelegate: Handling URL with super: \(url)")
        return super.application(app, open: url, options: options)
    }
}
