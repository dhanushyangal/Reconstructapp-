import Foundation
import WidgetKit

struct SharedDataModel {
    static let appGroupIdentifier = "group.com.mentalfitness.reconstruct.widgets"
    
    // MARK: - Simple Notes
    struct NotesData: Codable {
        let title: String
        let content: String
        let lastUpdated: Date
    }
    
    static func getNotesData() -> NotesData? {
        guard let userDefaults = UserDefaults(suiteName: appGroupIdentifier) else { return nil }
        if let data = userDefaults.data(forKey: "notesData"),
           let notesData = try? JSONDecoder().decode(NotesData.self, from: data) {
            return notesData
        }
        return NotesData(
            title: "My Notes",
            content: "Add your notes here",
            lastUpdated: Date()
        )
    }
    
    static func saveNotesData(_ data: NotesData) {
        guard let userDefaults = UserDefaults(suiteName: appGroupIdentifier) else { return }
        if let encoded = try? JSONEncoder().encode(data) {
            userDefaults.set(encoded, forKey: "notesData")
            WidgetCenter.shared.reloadAllTimelines()
        }
    }
}
