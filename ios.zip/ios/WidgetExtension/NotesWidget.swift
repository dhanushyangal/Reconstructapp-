import WidgetKit
import SwiftUI

struct NotesWidget: Widget {
    let kind: String = "NotesWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: NotesProvider()) { entry in
            NotesWidgetView(entry: entry)
        }
        .configurationDisplayName("Notes")
        .description("Quick access to your notes.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

struct NotesEntry: TimelineEntry {
    let date: Date
    let title: String
    let content: String
}

struct NotesProvider: TimelineProvider {
    typealias Entry = NotesEntry
    
    func placeholder(in context: Context) -> NotesEntry {
        NotesEntry(
            date: Date(), 
            title: "My Notes",
            content: "Add your notes here"
        )
    }

    func getSnapshot(in context: Context, completion: @escaping (NotesEntry) -> ()) {
        let currentDate = Date()
        let sharedData = SharedDataModel.getNotesData()
        
        let entry = NotesEntry(
            date: currentDate,
            title: sharedData?.title ?? "My Notes",
            content: sharedData?.content ?? "Add your notes here"
        )
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<NotesEntry>) -> ()) {
        let currentDate = Date()
        let sharedData = SharedDataModel.getNotesData()
        
        let entry = NotesEntry(
            date: currentDate,
            title: sharedData?.title ?? "My Notes",
            content: sharedData?.content ?? "Add your notes here"
        )

        let nextUpdate = Calendar.current.date(byAdding: .hour, value: 1, to: currentDate)!
        let timeline = Timeline(entries: [entry], policy: .after(nextUpdate))
        completion(timeline)
    }
}

struct NotesWidgetView: View {
    var entry: NotesEntry
    @Environment(\.widgetFamily) var family

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "note.text")
                    .foregroundColor(.blue)
                    .font(.title2)
                Text(entry.title)
                    .font(.headline)
                    .foregroundColor(.primary)
                Spacer()
            }
            
            if family == .systemMedium {
                Text(entry.content)
                    .font(.body)
                    .lineLimit(4)
                    .foregroundColor(.secondary)
            } else {
                Text(entry.content)
                    .font(.caption)
                    .lineLimit(3)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            HStack {
                Text("Notes")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                Spacer()
                Button(action: {
                    if let url = URL(string: "mentalfitness://notes") {
                        WidgetCenter.shared.reloadAllTimelines()
                    }
                }) {
                    Image(systemName: "square.and.pencil")
                        .foregroundColor(.blue)
                        .font(.title3)
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
    }
}

struct NotesWidget_Previews: PreviewProvider {
    static var previews: some View {
        NotesWidgetView(entry: NotesEntry(
            date: Date(), 
            title: "My Notes",
            content: "This is a sample note content for testing the widget."
        ))
        .previewContext(WidgetPreviewContext(family: .systemSmall))
        
        NotesWidgetView(entry: NotesEntry(
            date: Date(), 
            title: "My Notes",
            content: "This is a longer sample note content for testing the medium size widget. It should show more text."
        ))
        .previewContext(WidgetPreviewContext(family: .systemMedium))
    }
}

